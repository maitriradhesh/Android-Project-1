package com.example.homework1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    public static int iterationCount = 0;
    private TextView textCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textCount = findViewById(R.id.textCount);
        updateIterationCount();
    }

    @Override
    protected void onResume() {
        super.onResume();
        iterationCount++; // Increment the iteration count
        updateIterationCount();
    }
    private void updateIterationCount() {
        TextView textCount = findViewById(R.id.textCount);
        textCount.setText("Iteration Count: " + iterationCount);
    }

    public void onClick(View view) {
        startActivity(new Intent("com.example.homework1.SecondActivity"));

    }

}