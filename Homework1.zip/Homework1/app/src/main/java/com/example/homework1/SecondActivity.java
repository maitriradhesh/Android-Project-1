package com.example.homework1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        //MainActivity.iterationCount++;
        Log.d("SecondActivity", "Iteration Count: " + MainActivity.iterationCount);

    }

    public void onClick(View view) {
        //startActivity(new Intent("com.example.homework1.MainActivity"));
        finish();
    }
}